{
  "properties" : {
    "current.location" : ""
  },
  "import.local" : {
    "IDPregistry;;ped.ttl" : {
      "name" : "ped.ttl",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "https://idpcentral.org/registry/ped",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/ped.ttl",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "9d6fc829-d86f-4967-b3ee-29a879d0b299",
      "timestamp" : 1697016129474,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    },
    "IDPregistry;;mobidb.ttl" : {
      "name" : "mobidb.ttl",
      "status" : "DONE",
      "message" : "Imported successfully in 1s.",
      "context" : "https://idpcentral.org/registry/mobidb",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/mobidb.ttl",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "dcdb8438-d7d7-4559-a5ff-995bd823e1f8",
      "timestamp" : 1697016129508,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    },
    "IDPregistry;;disprot.ttl" : {
      "name" : "disprot.ttl",
      "status" : "DONE",
      "message" : "Imported successfully in 1s.",
      "context" : "https://idpcentral.org/registry/disprot",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/disprot.ttl",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "7142d471-45b2-49b0-a1b3-35f471a8058a",
      "timestamp" : 1697016129557,
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true
      }
    }
  }
}